import { User } from './user';

describe('User', () => {
    test('should create an instance', () => {
        expect(new User()).toBeTruthy();
    });
});
