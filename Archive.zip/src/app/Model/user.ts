export class User {
    id: Number;
    name: String;
    username: String;
    age: Number;
    city: String;
    isadmin: boolean;
}
